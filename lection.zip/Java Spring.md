
### Что такое Spring и Maven
Spring Framework - это, в первую очередь библиотека, так что вначале надо разобраться, как в Java подключаются внешние библиотеки. 
Для этого здесь существуют сборщики. Мы будем использовать один из них - Maven.
Все библиотеки лежат в одном месте - https://mvnrepository.com/repos/central
Именно из него сборщики загружают библиотеки.
Если кто-то программировал на питоне, вы должны были слышать про pip, всё это похоже на него.

Информация, о том, какие библиотеки используются в проекте лежит в файле pom.xml
При запуске приложения сборщик компилирует всё и кладёт в одну папку(обычно target или build)

Spring тесно связан с различными паттернами проектирования и имеет свою идеологию, в которой подробно рассказывается как нужно под него писать. Сильно вникать в это мы не будем, затронем только 2 понятия - Inversion of control и dependency injection 
- Обычно, когда вы пишете программу на Java у вас есть точка входа - метод main, который вы запускаете. Все, что вы хотите сделать, так или иначе вызывается из него. В Spring всё не так. У вас  также есть метод main, но выглядит он примерно так:
```java
@SpringBootApplication  
public class SpringTutorialApplication {  
  
    public static void main(String[] args) {  
        SpringApplication.run(SpringTutorialApplication.class, args);  
    }  
  
}
```
Таким образом, не вы, а сам фреймворк решает что и в каком порядке вызывать, когда и какие объекты создавать, куда их передавать. это называется Inversion of control.

- Из этого вытекает проблема: Предположим у вас есть класс базы данных, и класс Controller, который от неё зависит. Если бы вы писали как обычно, получилось бы что-то такое:
```java
@SpringBootApplication  
public class SpringTutorialApplication {  
  
    public static void main(String[] args) {  
        Database bd = new Database();
        Controller controller = new Controller(db); // тут мы явно передаем уже созданный объект
    }  
  
}
```
Но в Spring мы не управляем созданием и передачей объектов напрямую. Для этого используется Dependency injection. 
```java 
//Database.java
@Service 
class Database {
	...
}

// Controller.java
class Controller {
	Database db;
	public Controller(Database db) {
		this.db = db
	}
	...
}
```
Аннотация `@Service` говорит спрингу, что этот класс будет использоваться  в других местах. Spring создаст его экземпляр и сам передаст всем зависимым от него объектам

### ООП,  JSON и как они связаны

В JavaScript  мы уже научились "посылать запрос", но мы передаем в него параметры как JS объект - по сути, словарь, мапа. А на сервере мы хотим получить Java объект, что делать?

### Получение данных на сервере

Вспомним, как мы посылали запрос из JS:
```json
{
	classNumber: "108",
	teacherFio: "Тестов Тест Тестович",
	reason: "важные занятия",
	startTime: '01.01.2023 10:00:00',
	endTime: '01.01.2023 12:00:00'
}
```

Вспомним, что мы написали на прошлом занятии:
```Java
public void addReservation(Reservation reservation) {
//... 
// тут какая-то логика проверки того, что бронирование не пересекается с существющими
this.reservations.add(reservation);
}
```

Давайте попробуем подружить эти 2 формата

Напишем функцию, которая будет принимать в параметрах всю необходимую информацию, создавать бронирование и сохранять его
```java
void createReservation(  
        String classNumber,  
        String teacherFio,  
        String reason,  
        Date startTime,  
        Date endTime  
) {  
    Reservation reservation = new Reservation(  
            classNumber, teacherFio, reason, startTime, endTime  
    );  
    // проверка того, что бронирование не пересекается
	// тут нужно его куда-то сохранить, но куда? 
	save(reservation)
}
```
Что должен делать метод save? Записывать информацию куда-нибудь, в будущем - в базу данных. Пока мы не знаем, что это такое, поэтому воспользуемся "заглушкой" (обычно таки штуки называют mock) - объектом, с которым можно работать как с базой данных, но при ей не являющимся. 
(В нашем случае класс DatabaseMock)
```java
Database db = new DatabaseMock(); // Обратите внимание, что db имеет тип Database, а не DatabaseMock. Database - это интерфейс, который имплементится классом DatabaseMock. Мы используем именно интерфейс, чтобы в будущем, когда у нас появится класс для работы с настоящей базой данных, мы могли изменить всего одну строчку:
// Database db = new MariaDBDatabase();
// При этом весь остальной код менять не нужно
db.saveReservation(reservation);
```

Отлично, но кто будет вызывать метод ```createReservation()```? 

Он должен вызываться сам, когда клиент вызывает метод ```post('/create_reservation')``` (помните у нас в JavaScript был такой?) 

Фреймворк Spring позволяет легко превратить функцию в ```createReservation()``` в хендлер HTTP запроса
```java
@RestController  
public class HttpController {  
    @PostMapping(value = "/create_reservation", produces = "application/json")  
    // value - это относительный путь, при запросе на который будет вызываться метод
    // Например, если адрес сайта - 127.0.0.1:8080, то метод вызовется при запросе на 
    // 127.0.0.1:8080/create_reservation
    // produces отвечает за выставление хедера content-type в ответе, в целом, можно его 
    // не указывать
    String createReservation(
            @RequestParam String classNumber,  
            @RequestParam String teacherFio,  
            @RequestParam String reason,  
            @RequestParam Date startTime,  
            @RequestParam Date endTime  
    ) {  
        Reservation reservation = new Reservation(  
                classNumber, teacherFio, reason, startTime, endTime  
        );  
        return db.saveReservation(reservation); // Мы не создаем объект db, спринг сам нам его подсунет потому что dependency injection
    }  
}

```
`@RequestParam` означает, что мы хотим получить этот параметр из http запроса. Spring сам его за нас распарсит и подставит сюда значение. Если параметра с заданным названием нет, Spring вернет 400 ошибку

### Немного про базы данных и id
Только что мы научились добавлять бронирование, но что если мы захотим изменить уже существующее? Как мы сможем указать на конкретный объект? В базах данных для этого используется поле id. Оно есть у каждого сохранённого объекта. 

Раз оно есть у всех объектов, которые хранятся в бд, создадим класс, который будет отвечать за работу с этим полем 
```Java
public class DatabaseObject {  
    protected int id;  
  
    public int getId() {  
        return id;  
    }  
  
    public void setId(int id) {  
        this.id = id;  
    }  
}
```
Все остальные классы, которые мы захотим сохранять в базе данных, должны будут наследоваться от него

Теперь давайте научимся отдавать информацию о бронированиях

Посмотрим ещё раз на наш класс 
```Java
public class Reservation extend DatabaseObject {
	private int roomId; 
	private int teacherId;  
	private String reason;  
	private Date startTime;  
	private Date endTime;  
	
	...
}
```

Вспомним, что мы хотим получить
```json
{
	roomId: 4,
	teacherId: 1,
	reason: "важные занятия",
	startTime: '01.01.2023 10:00:00',
	endTime: '01.01.2023 12:00:00'
}
```

Есть что-то общее, правда?

Можно, конечно, написать сериализатор руками, однако этим вы наверняка успеете заняться в институте, а пока предлагаю не изобретать велосипеды и воспользоваться готовой библиотекой  Jackson.

Здесь мы по-хорошему должны вернуть строку вроде той, что посылаем из javascript в методе post, по почему-то возвращаем объект, как это работает?

Spring увидит, что мы вернули не String и попытается привести этот объект к jsonу используя Jackson. Однако тот умеет приводить простые типы, а вот что делать с типом Date он не знает. Надо помочь:
```java
@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy hh:mm")  
private Date startTime;  
@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy hh:mm")  
private Date endTime;
```
Чтобы Jackson мог работать, у для всех полей классов должны быть прописаны геттеры и сеттеры

Но теперь у нас есть проблема: в списке бронирований на клиенте мы хотим видеть не id учителей и кабинетов, а что-то более человекочитаемое. 


### Но

До этого мы делали понятные вещи, но хорошего понемногу, теперь надо чуть-чуть поколдовать

В файл `application.properties` Нужно обязательно дописать
```
server.servlet.session.cookie.http-only=false  
server.servlet.session.cookie.secure=false
```

И над HttpController дописать 
```java
@CrossOrigin(allowCredentials = "true", originPatterns = "*")
```

Иначе будет такое:
![img](Pasted%20image%2020221220000425.png)

### Задания
1) Поддержать возможности сайта с предыдущих занятий: /get_reserations, /get_rooms, /get_teachers
2) починить сломавшееся отображение бронирований
- Нужно при загрузке страницы выгружать список учителей, кабинетов, сохранить их как мапу кабинетов и учителей.
- Посылать запрос на список бронирований только когда эти запросы дойдут
- Доставать нужные нам значения (фио учителя, номер кабинета) по id из сформированных мап

3) реализовать создание бронирования
- запрос `/create_reservation`
- Использовать выпадающие списки при выборе кабинета и учителя
4) Добавить возможность поиска бронирований в определённом промежутке времени
- допилить главную страницу, добавить инпуты для ввода времени
- в DatabaseMock есть метод `getReservations(Date startTime, Date endTime)`
- строку можно распарсить на сервере при помощи 
```java
SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy hh:mm");
Date dt = sdf.parse("11.10.2022 10:00")
```


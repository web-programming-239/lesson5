package ru.course.data.dbmock;

import org.springframework.stereotype.Service;
import ru.course.data.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class DatabaseMock implements Database {
    // Тут генерируются тестовые данные, как именно, понимать необязательно
    // Можно пользоваться всеми методами описанными в интерфейсе Database
    private final List<DatabaseObject> objects;
    int id = 0;

    public DatabaseMock() throws ParseException {
        objects = new ArrayList<>();
        int RESERVATIONS_AMOUNT = 10;
        Random random = new Random();

        String[] teachers = new String[]{"Ушаков Д.М.", "Лянгузов Ф.А.", "Мирзаянов М.Р."};
        List<Integer> teacherIds = Arrays.stream(teachers).map(Teacher::new).map(this::addObject).toList();

        String[] rooms = new String[]{"208", "303", "108"};
        String[] infos = new String[]{"Компьютерный класс", "Ни чем не выделяющийся кабинет"};

        List<Integer> roomIds = Arrays.stream(rooms)
                .map(s ->
                        new Room(
                                s,
                                teacherIds.get(random.nextInt(teacherIds.size())),
                                infos[random.nextInt(infos.length)]
                        ))
                .map(this::addObject).toList();

        String[] purposes = new String[]{"занятие 1", "занятие 2", "занятие 3"};
        for (int i = 0; i < RESERVATIONS_AMOUNT; i++) {
            List<Date> time = generateTime();
            addObject(new Reservation(
                    roomIds.get(random.nextInt(roomIds.size())),
                    teacherIds.get(random.nextInt(teacherIds.size())),
                    purposes[random.nextInt(purposes.length)],
                    time.get(0),
                    time.get(1)
            ));
        }
    }


    public int addObject(DatabaseObject obj) {
        obj.setId(id++);
        objects.add(obj);
        return id - 1;
    }

    public DatabaseObject getById(int id) {
        for (DatabaseObject obj :
                objects) {
            if (obj.getId() == id) return obj;
        }
        return null;
    }

    private static List<Date> generateTime() throws ParseException {
        Random rand = new Random();
        int date = rand.nextInt(29) + 1;
        int month = rand.nextInt(11) + 1;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm");
        return Arrays.asList(
                sdf.parse("%02d.%02d.2023 11:00".formatted(date, month)),
                sdf.parse("%02d.%02d.2023 12:00".formatted(date, month))
        );
    }

    @Override
    public void saveReservation(Reservation reservation) {
        addObject(reservation);
    }

    @Override
    public List<Reservation> getReservations() {
        List<Reservation> res = new ArrayList<>();
        for (DatabaseObject obj :
                objects) {
            if (obj instanceof Reservation) {
                res.add((Reservation) obj);
            }
        }
        return res;
    }

    @Override
    public List<Reservation> getReservations(Date startTime, Date endTime) {
        List<Reservation> res = new ArrayList<>();
        for (DatabaseObject obj :
                objects) {
            if (obj instanceof Reservation r) {
                if (r.getStartTime().compareTo(startTime) >= 0 && r.getEndTime().compareTo(endTime) <= 0) {
                    res.add(r);
                }
            }
        }
        return res;
    }

    @Override
    public List<Room> getRooms() {
        List<Room> res = new ArrayList<>();
        for (DatabaseObject obj :
                objects) {
            if (obj instanceof Room r) {
                res.add(r);
            }
        }
        return res;
    }

    @Override
    public List<Teacher> getTeachers() {
        List<Teacher> res = new ArrayList<>();
        for (DatabaseObject obj :
                objects) {
            if (obj instanceof Teacher r) {
                res.add(r);
            }
        }
        return res;
    }

    @Override
    public Reservation getReservationById(int id) {
        return (Reservation) getById(id);
    }

    @Override
    public Room getRoomById(int id) {
        return (Room) getById(id);
    }

    @Override
    public Teacher getTeacherById(int id) {
        return (Teacher) getById(id);
    }
}

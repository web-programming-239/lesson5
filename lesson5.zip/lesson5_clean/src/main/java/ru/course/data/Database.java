package ru.course.data;

import java.util.Date;
import java.util.List;

public interface Database {
    void saveReservation(Reservation reservation);

    List<Reservation> getReservations();

    List<Reservation> getReservations(Date startTime, Date endTime);

    List<Room> getRooms();

    List<Teacher> getTeachers();

    Reservation getReservationById(int id);

    Room getRoomById(int id);

    Teacher getTeacherById(int id);

}

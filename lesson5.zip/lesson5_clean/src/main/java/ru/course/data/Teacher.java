package ru.course.data;

import java.util.Random;

public class Teacher extends DatabaseObject{
    private String fullName;
    private String mood;
    private static final String[] moods = new String[] {"хорошее", "не очень", "дед инсид"};

    public Teacher(String fullName) {
        this.fullName = fullName;
        Random random = new Random();
        this.mood = moods[random.nextInt(moods.length)];
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMood() {
        return mood;
    }

    public void setMood(String mood) {
        this.mood = mood;
    }
}

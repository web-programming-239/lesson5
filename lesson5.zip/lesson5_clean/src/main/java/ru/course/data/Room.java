package ru.course.data;

public class Room extends DatabaseObject {
    private String classNumber;
    private int teacherId;
    private String info;

    public Room(String classNumber, int teacherId, String info) {
        this.classNumber = classNumber;
        this.teacherId = teacherId;
        this.info = info;
    }

    public String getClassNumber() {
        return classNumber;
    }

    public void setClassNumber(String classNumber) {
        this.classNumber = classNumber;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }
}

package ru.course.data;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.util.Date;

public class Reservation extends DatabaseObject{
    private int roomId;
    private int teacherId;
    private String purpose;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy HH:mm", timezone = "GMT+3")
    private Date startTime;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd.MM.yyyy HH:mm", timezone = "GMT+3")
    private Date endTime;

    public Reservation(int roomId, int teacherId, String purpose, Date startTime, Date endTime) {
        this.roomId = roomId;
        this.teacherId = teacherId;
        this.purpose = purpose;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public int getRoomId() {
        return roomId;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
}

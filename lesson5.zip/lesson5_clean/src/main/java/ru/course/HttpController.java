package ru.course;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import ru.course.data.Database;
import ru.course.data.Reservation;
import ru.course.data.Room;
import ru.course.data.Teacher;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@RestController
@CrossOrigin(allowCredentials = "true", originPatterns = "*")
public class HttpController {
    Database db;


    public HttpController(Database db) {
        this.db = db;
    }

    @PostMapping(value = "/create_reservation", produces = "application/json")
    String createReservation(
            @RequestParam int roomId,
            @RequestParam int teacherId,
            @RequestParam String purpose,
            @RequestParam String startTime,
            @RequestParam String endTime
    ) {
       return null;
    }

    @GetMapping(value = "/get_reservations", produces = "application/json")
    List<Reservation> getReservations() {
        return null;
    }

    @GetMapping(value = "/get_rooms", produces = "application/json")
    List<Room> getRoms() {
        return null;
    }

    @GetMapping(value = "/get_teachers", produces = "application/json")
    List<Teacher> getTeachers() {
        return null;
    }
}
